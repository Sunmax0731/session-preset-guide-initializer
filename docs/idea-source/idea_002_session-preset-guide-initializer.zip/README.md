# 導入プリセット・操作ガイド・セッション初期化 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 2 |
| 分野 | 起動・初期化 |
| アイデア | 導入プリセット・操作ガイド・セッション初期化 |
| リポジトリ名 | session-preset-guide-initializer |
| 概要 | 用途別プリセット、頻出操作、危険操作確認、ルートディレクトリ設定、Skill.md、Agents.md、Design.md、TODO.md、工程別テンプレート生成をまとめる。 |
| 課題 | 新規プロジェクトや再開時に、作業ルール、初期構成、操作手順を整えるだけで時間とトークンを使いやすい。 |
| 類似サービス・アプリ | cookiecutter, Yeoman, GitHub Template Repository, Copier, Plop |
| 差別化ポイント | Codexセッションの開始文脈とGitHub運用を前提に、必要な文書と操作だけを出す。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `導入プリセット・操作ガイド・セッション初期化` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
