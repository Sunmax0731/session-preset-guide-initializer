# 01 要件定義: 導入プリセット・操作ガイド・セッション初期化

## 背景

用途別プリセット、頻出操作、危険操作確認、ルートディレクトリ設定、Skill.md、Agents.md、Design.md、TODO.md、工程別テンプレート生成をまとめる。

## 課題

新規プロジェクトや再開時に、作業ルール、初期構成、操作手順を整えるだけで時間とトークンを使いやすい。

## 対象ユーザー

- `起動・初期化` 領域で継続的に作業するユーザー。
- 既存の代替手段が広すぎる、重すぎる、または分断されていると感じているユーザー。
- 入力、確認、処理、出力、履歴を一つの流れで扱いたいユーザー。

## ユーザー価値

- ツールや画面を行き来する負担を減らす。
- 判断、設定、結果、エラーを後から追える形で残す。
- 製品上で次の差別化ポイントが分かるようにする: Codexセッションの開始文脈とGitHub運用を前提に、必要な文書と操作だけを出す。

## MVP機能要件

- FR-1: ユーザーは対象データまたは作業項目を入力、選択、取り込みできる。
- FR-2: ユーザーは取り込んだ内容を一覧、プレビュー、状態ビューで確認できる。
- FR-3: 中核となる `起動・初期化` の処理を実行できる。
- FR-4: 結果、判断、エラー、履歴を保存または書き出しできる。
- FR-5: 失敗時は原因、再試行、スキップ、復旧操作を表示する。

## Non-functional Requirements

- Keep small personal datasets responsive.
- Require confirmation or preview before destructive actions.
- Do not send local files, credentials, or assets externally without explicit intent.
- Keep enough logs for troubleshooting and repeatability.

## Out of Scope for MVP

- Replacing every feature of similar products.
- Complex team permission management.
- Automation that depends on unverified third-party terms or unstable pages.

## Acceptance Criteria

- The main flow works from input to output/save.
- Normal, failure, and cancel paths can be tested.
- The differentiation is visible in UI or workflow behavior.
