あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Apps
- 領域: ProjectManagement
- No.: 2
- 分野: 起動・初期化
- アイデア: 導入プリセット・操作ガイド・セッション初期化
- リポジトリ名: session-preset-guide-initializer

## 元アイデア

- 概要: 用途別プリセット、頻出操作、危険操作確認、ルートディレクトリ設定、Skill.md、Agents.md、Design.md、TODO.md、工程別テンプレート生成をまとめる。
- 課題: 新規プロジェクトや再開時に、作業ルール、初期構成、操作手順を整えるだけで時間とトークンを使いやすい。
- 類似サービス・アプリ: cookiecutter, Yeoman, GitHub Template Repository, Copier, Plop
- 差別化ポイント: Codexセッションの開始文脈とGitHub運用を前提に、必要な文書と操作だけを出す。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- 主要ユーザー、ローカル保存、権限、バックアップ、外部API境界を明確にする。
- 入力から確認、履歴、出力までの一連の流れを設計する。
- 日常利用フロー、データ復旧、プライバシーに関わる挙動を検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
